export class Employee {
    empId: number;
    fullName: string;
    emailId: string;
    address: string;
    manager: string;
    mobile: string;
    project: string;
    
}
